/*
 * Author: Isaac Ocegueda
 * Date: 2/9/2024
 * Class: CS 320
 */

package main;

import java.util.Date; // import date class

public class Appointment {
	// variables needed for appointment
	private String appointmentId;
	private Date appointmentDate;
	private String appointmentDescription;	
	
	// create an instance of an appointment
	public Appointment(String appointmentId, Date appointmentDate, String appointmentDescription) {
		
		// check that each field meets the requirements
		
		// ID string cannot be longer than 10 char and cannot be null
		if(appointmentId == null || appointmentId.length() > 10) {
			throw new IllegalArgumentException("Invalid ID. ID cannot be left blank or longer than 10 numbers.");
		}
				
		// appointment date cannot be in the past or null
		if(appointmentDate == null || appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid date. Appointment date cannot be left blank or in the past.");
		}
				
		// Appointment description cannot be longer than 50 characters and cannot be null
		if(appointmentDescription == null || appointmentDescription.length() > 50) {
			throw new IllegalArgumentException("Invalid appointment description. Description cannot be left blank or longer than 50 letters.");
		}
		
		this.appointmentId = appointmentId;
		this.appointmentDate = appointmentDate;
		this.appointmentDescription = appointmentDescription;
	}
	
	// getter and setter methods
	
	public String getAppointmentId() {
		return appointmentId;
	}
	
	public void setAppointmentId(String appointmentId) {
		// ID string cannot be longer than 10 char and cannot be null
		if(appointmentId == null || appointmentId.length() > 10) {
			throw new IllegalArgumentException("Invalid ID. ID cannot be left blank or longer than 10 numbers.");
		}
		this.appointmentId = appointmentId;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		// Appointment date cannot be in the past and cannot be null
		if(appointmentDate == null || appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid date. Appointment date cannot be left blank or in the past.");
		}
		this.appointmentDate = appointmentDate;
	}
	
	public String getAppointmentDescription() {
		return appointmentDescription;
	}
	
	public void setAppointmentDescription(String appointmentDescription) {
		// Appointment description cannot be longer than 50 characters and cannot be null
		if(appointmentDescription == null || appointmentDescription.length() > 50) {
			throw new IllegalArgumentException("Invalid appointment description. Description cannot be left blank or longer than 50 letters.");
		}
		this.appointmentDescription = appointmentDescription;
	}
}
