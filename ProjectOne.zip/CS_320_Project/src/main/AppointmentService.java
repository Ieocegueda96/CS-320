/*
 * Author: Isaac Ocegueda
 * Date: 2/9/2024
 * Class: CS 320
 */


package main;

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {

	// create array to store appointments
	public static ArrayList<Appointment> appointmentList = new ArrayList<>();
	
	// method to create and add appointment to appointmentList array
	public static  void addAppointment(String appointmentId, Date appointmentDate, String appointmentDescription) {
		Appointment newAppointment = new Appointment(appointmentId, appointmentDate, appointmentDescription);
		appointmentList.add(newAppointment);
	}
	
	// method to delete a appointment
	public static  void deleteAppointment(String uniqueId) {
		for (int i = 0; i < appointmentList.size(); i++) { // run through all the appointment Id's
			if (uniqueId.compareTo(appointmentList.get(i).getAppointmentId()) == 0) { // find a matching id
				int appointment = i; // set an integer id to the one found
				appointmentList.remove(appointment); // deletes the appointment with that id form array
			}
		}
	}
	
	// search function using id, for testing
	public static int searchAppointment(String uniqueId) {
		int result = 0;
		for (int i = 0; i < appointmentList.size(); i++) {
			if (uniqueId.compareTo(appointmentList.get(i).getAppointmentId()) == 0) {
				result = 1; // contact was found
			}
			else {
				result = 2; // contact was not found
			}
		}
		return result;
	}
}
