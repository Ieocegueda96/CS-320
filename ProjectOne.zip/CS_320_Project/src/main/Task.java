/*
 * Author: Isaac Ocegueda
 * Date: 2/1/2024
 * Class: CS 320
 */

package main;

public class Task {
	// variables needed for task
	private String taskId;
	private String taskName;
	private String taskDescription;
	
	// create an instance of a task, or task object
	public Task(String taskId, String taskName, String taskDescription) {
		
		// check that each field meets the requirements
		
		// ID string cannot be longer than 10 char and cannot be null
		if(taskId == null || taskId.length() > 10) {
			throw new IllegalArgumentException("Invalid ID. ID cannot be left blank or longer than 10 numbers.");
		}
				
		// Task name cannot be longer than 20 characters and cannot be null
		if(taskName == null || taskName.length() > 20) {
			throw new IllegalArgumentException("Invalid task name. Task name cannot be left blank or longer than 20 letters.");
		}
				
		// Task description cannot be longer than 30 characters and cannot be null
		if(taskDescription == null || taskDescription.length() > 30) {
			throw new IllegalArgumentException("Invalid task description. Description cannot be left blank or longer than 30 letters.");
		}
		
		this.taskId = taskId;
		this.taskName = taskName;
		this.taskDescription = taskDescription;
	}
	
	// getter and setter methods
	
	public String getTaskId() {
		return taskId;
	}
	
	// no setter for Id since it cannot be updated.
	
	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		// Task name cannot be longer than 20 characters and cannot be null
		if(taskName == null || taskName.length() > 20) {
			throw new IllegalArgumentException("Invalid task name. Task name cannot be left blank or longer than 20 letters.");
		}
		this.taskName = taskName;
	}
	
	public String getTaskDescription() {
		return taskDescription;
	}
	
	public void setTaskDescription(String taskDescription) {
		// Task description cannot be longer than 30 characters and cannot be null
		if(taskDescription == null || taskDescription.length() > 30) {
			throw new IllegalArgumentException("Invalid task description. Description cannot be left blank or longer than 30 letters.");
		}
		this.taskDescription = taskDescription;
	}
}
