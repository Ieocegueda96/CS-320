/*
 * Author: Isaac Ocegueda
 * Date: 2/1/2024
 * Class: CS 320
 */

package main;

//import arraylist function
import java.util.ArrayList;


public class TaskService {
	// create array to store tasks
	public static ArrayList<Task> taskList = new ArrayList<>();
	
	// method to create and add contact to contactList array
	public static void addTask(String taskId, String taskName, String taskDescription) {
		Task newTask = new Task(taskId, taskName, taskDescription);
		taskList.add(newTask);
	}
	
	// method to delete a task
	public static void deleteTask(String uniqueId) {
		for (int i = 0; i < taskList.size(); i++) { // run through all the task Id's
			if (uniqueId.compareTo(taskList.get(i).getTaskId()) == 0) { // find a matching id
				int task = i; // set an integer id to the one found
				taskList.remove(task); // deletes the task with that id form array
			}
		}
	}
	
	// methods to update fields
	// update task name
	public static void updateTaskName(String uniqueId, String newTaskName) {
		for (int i = 0; i < taskList.size(); i++) { // run through all the task Id's
			if (uniqueId.compareTo(taskList.get(i).getTaskId()) == 0) { // find a matching id
				taskList.get(i).setTaskName(newTaskName); // updates to new task name
			}
		}
	}
	
	// update task description
	public static void updateTaskDescription(String uniqueId, String newDescription) {
		for (int i = 0; i < taskList.size(); i++) { // run through all the task Id's
			if (uniqueId.compareTo(taskList.get(i).getTaskId()) == 0) { // find a matching id
				taskList.get(i).setTaskDescription(newDescription); // updates to new task description
			}
		}
	}
	
	// search function using id, for testing
		public static int searchTask(String uniqueId) {
			int result = 0;
			for (int i = 0; i < taskList.size(); i++) {
				if (uniqueId.compareTo(taskList.get(i).getTaskId()) == 0) {
					result = 1; // contact was found
				}
				else {
					result = 2; // contact was not found
				}
			}
			return result;
		}
}
