/*
 * Author: Isaac Ocegueda
 * Date: 1/25/2024
 * Class: CS 320
 */

package main;

// import arraylist function
import java.util.ArrayList;

public class ContactService {
	
	// create array to store contacts
	public static ArrayList<Contact> contactList = new ArrayList<Contact>(0);
	
	// method to create and add contact to contactList array
	public static void addContact(String contactId, String firstName, String lastName, String phone, String address) {
		Contact newContact = new Contact(contactId, firstName, lastName, phone, address);
		contactList.add(newContact);
	}
	
	// method to delete a contact
	public static void deleteContact(String uniqueId) {
		for (int i = 0; i < contactList.size(); i++) { // run through all the contact Id's
			if (uniqueId.compareTo(contactList.get(i).getContactId()) == 0) { // find a matching id
				int contact = i; // set an integer id to the one found
				contactList.remove(contact); // deletes the contact with that id form array
			}
		}
	}
	
	// methods to update fields
	// update first name
	public static void updateFirstName(String uniqueId, String newFirstName) {
		for (int i = 0; i < contactList.size(); i++) { // run through all the contact Id's
			if (uniqueId.compareTo(contactList.get(i).getContactId()) == 0) { // find a matching id
				contactList.get(i).setFirstName(newFirstName); // updates to new first name
			}
		}
	}
	
	// update last name
	public static void updateLastName(String uniqueId, String newLastName) {
		for (int i = 0; i < contactList.size(); i++) { // run through all the contact Id's
			if (uniqueId.compareTo(contactList.get(i).getContactId()) == 0) { // find a matching id
				contactList.get(i).setLastName(newLastName); // updates to new last name
			}
		}
	}
	
	//update phone number
	public static void updatePhone(String uniqueId, String newPhone) {
		for (int i = 0; i < contactList.size(); i++) { // run through all the contact Id's
			if (uniqueId.compareTo(contactList.get(i).getContactId()) == 0) { // find a matching id
				contactList.get(i).setPhone(newPhone); // updates to new phone number
			}
		}
	}
	
	// update address
	public static void updateAddress(String uniqueId, String newAddress) {
		for (int i = 0; i < contactList.size(); i++) { // run through all the contact Id's
			if (uniqueId.compareTo(contactList.get(i).getContactId()) == 0) { // find a matching id
				contactList.get(i).setAddress(newAddress); // updates to new address
			}
		}
	}

	// search function using id, for testing
	public static int searchContact(String contactId) {
		int result = 0;
		for (int i = 0; i < contactList.size(); i++) {
			if (contactId.compareTo(contactList.get(i).getContactId()) == 0) {
				result = 1; // contact was found
			}
			else {
				result = 2; // contact was not found
			}
		}
		return result;
	}

}
