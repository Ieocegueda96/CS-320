/*
 * Author: Isaac Ocegueda
 * Date: 1/25/2024
 * Class: CS 320
 */

package main;

public class Contact {
	// set variables needed for contacts
	private String contactId;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	// create an instance of a contact
	public Contact(String contactId, String firstName, String lastName, String phone, String address) {
		// check that each field meets the requirements
		
		// ID string cannot be longer than 10 char and cannot be null
		if(contactId == null || contactId.length() > 10) {
			throw new IllegalArgumentException("Invalid ID. ID cannot be left blank or longer than 10 numbers.");
		}
		
		// First name cannot be longer than 10 characters and cannot be null
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name. First name cannot be left blank or longer than 10 letters.");
		}
		
		// Last name cannot be longer than 10 characters and cannot be null
		if(lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name. Last name cannot be left blank or longer than 10 letters.");
		}
		
		// Phone number cannot be longer than 10 characters and cannot be null
		if(phone == null || phone.length() != 10) {
			throw new IllegalArgumentException("Invalid phone number. Number cannot be left blank and must be 10 digits.");
		}
		
		// Address cannot be longer than 30 characters and cannot be null
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address. Address cannot be left blank or longer than 30 characters.");
		}
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}

	// Getter and setter methods
	public String getContactId() {
		return contactId;
	}
	// no setter for Id since it cannot be updated.
	
	public String getFirstName() {
		return firstName;
	}
	
	public void setFirstName(String firstName) {
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid first name. First name cannot be left blank or longer than 10 letters.");
		}
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid last name. Last name cannot be left blank or longer than 10 letters.");
		}
		this.lastName = lastName;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		if(phone == null || phone.length() != 10) {
			throw new IllegalArgumentException("Invalid phone number. Number cannot be left blank and must be 10 digits.");
		}
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid address. Address cannot be left blank or longer than 30 characters.");
		}
		this.address = address;
	}
}
