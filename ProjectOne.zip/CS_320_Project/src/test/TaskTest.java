/*
 * Author: Isaac Ocegueda
 * Date: 2/1/2024
 * Class: CS 320
 */

package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.Task;

class TaskTest {

	// test for creation of Task class
	@Test
	void testTaskClass() {
		Task testTask = new Task("1000000001", "Task1", "Testing the task");
		assertTrue(testTask.getTaskId().equals("1000000001"));
		assertTrue(testTask.getTaskName().equals("Task1"));
		assertTrue(testTask.getTaskDescription().equals("Testing the task"));
	}
		
	// test for id null
	@Test
	void testTaskClassIdIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Task1", "Testing the task");
		});
	}
		
	// test for id too long
	@Test
	void testTaskClassIdIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("10000000010", "Test1", "Testing the task");
		});
	}
		
	// test for task name null
	@Test
	void testTaskClassTaskNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1000000001", null, "Testing the task");
		});
	}
		
	// test for task name too long
	@Test
	void testTaskClassTaskNameIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1000000001", "Test00000000000000001", "Testing the task");
		});
	}
		
	// test for task description null
	@Test
	void testTaskClassTaskDescriptionIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1000000001", "Test1", null);
		});
	}
		
	// test for task description too long
	@Test
	void testTaskClassTaskDescriptionIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1000000001", "Test1", "Testing description over 30 char");
		});
	}
	
	// test setters. Each setter is tested for correct, null, and for too long
	
	// test task name
	@Test
	void testTaskClassSetTaskName() {
		Task testTask = new Task("1000000001", "Test1", "Testing the task");
		testTask.setTaskName("Task2");
		assertTrue(testTask.getTaskName().equals("Task2"));
	}
		
	@Test
	void testTaskClassSetTaskNameIsNull() {
		Task testTask = new Task("1000000001", "Test1", "Testing the task");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
				testTask.setTaskName(null);
		});
	}
		
	@Test
	void testTaskClassSetTaskNameIsTooLong() {
		Task testTask = new Task("1000000001", "Test1", "Testing the task");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			testTask.setTaskName("Test00000000000000001");
		});
	}

	// test task description
	@Test
	void testTaskClassSetTaskDescription() {
		Task testTask = new Task("1000000001", "Test1", "Testing the task");
		testTask.setTaskDescription("Second description");
		assertTrue(testTask.getTaskDescription().equals("Second description"));
	}
		
	@Test
	void testTaskClassSetTaskDescriptionIsNull() {
		Task testTask = new Task("1000000001", "Test1", "Testing the task");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			testTask.setTaskDescription(null);
		});
	}
		
	@Test
	void testTaskClassSetTaskDescriptionIsTooLong() {
		Task testTask = new Task("1000000001", "Test1", "Testing the task");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			testTask.setTaskDescription("Testing description over 30 char");
		});
	}
}
