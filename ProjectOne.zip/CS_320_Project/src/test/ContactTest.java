/*
 * Author: Isaac Ocegueda
 * Date: 1/25/2024
 * Class: CS 320
 */

package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.Contact;

class ContactTest {

	// test for creation of contact class
	@Test
	void testContactClass() {
		Contact testContact = new Contact("1000000001", "Isaac", "Ocegueda",
				"2565580000", "123 Main St, Boaz, AL 35957");
		assertTrue(testContact.getContactId().equals("1000000001"));
		assertTrue(testContact.getFirstName().equals("Isaac"));
		assertTrue(testContact.getLastName().equals("Ocegueda"));
		assertTrue(testContact.getPhone().equals("2565580000"));
		assertTrue(testContact.getAddress().equals("123 Main St, Boaz, AL 35957"));
	}
	
	// test for id null
	@Test
	void testContactClassIdIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		});
	}
	
	// test for id too long
	@Test
	void testContactClassIdIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("10000000010", "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		});
	}
	
	// test for first name null
	@Test
	void testContactClassFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1000000001", null, "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		});
	}
	
	// test for first name too long
	@Test
	void testContactClassFirstNameIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1000000001", "Isaac000001", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		});
	}
	
	// test for last name null
	@Test
	void testContactClassLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1000000001", "Isaac", null,
					"2565580000", "123 Main St, Boaz, AL 35957");
		});
	}
	
	// test for last name too long
	@Test
	void testContactClassLastNameIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1000000001", "Isaac", "Ocegueda001",
					"2565580000", "123 Main St, Boaz, AL 35957");
		});
	}

	// test for phone number null
	@Test
	void testContactClassPhoneIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1000000001", "Isaac", "Ocegueda",
					null, "123 Main St, Boaz, AL 35957");
		});
	}

	// test for phone number not 10 digits
	@Test
	void testContactClassPhoneNotTenDigits() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1000000001", "Isaac", "Ocegueda",
					"25655800001", "123 Main St, Boaz, AL 35957");
		});
	}

	// test address is null
	@Test
	void testContactClassAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", null);
		});
	}
	
	// test address is too long
	@Test
	void testContactClassAddressIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", "1234567 Main St, Boaz, AL 35957");
		});
	}
	
	// test setters. Each setter is tested for correct, null, and for too long
	
	// test first name
	@Test
	void testContactClassSetFirstName() {
		Contact testContact = new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		testContact.setFirstName("Ismael");
		assertTrue(testContact.getFirstName().equals("Ismael"));
	}
	
	@Test
	void testContactClassSetFirstNameIsNull() {
		Contact testContact = new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			testContact.setFirstName(null);
		});
	}
	
	@Test
	void testContactClassSetFirstNameIsTooLong() {
		Contact testContact = new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			testContact.setFirstName("Isaac123456");
		});
	}

	// test last name
	@Test
	void testContactClassSetLastName() {
		Contact testContact = new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		testContact.setLastName("Ortega");
		assertTrue(testContact.getLastName().equals("Ortega"));
	}
	
	@Test
	void testContactClassSetLastNameIsNull() {
		Contact testContact = new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			testContact.setLastName(null);
		});
	}
	
	@Test
	void testContactClassSetLastNameIsTooLong() {
		Contact testContact = new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			testContact.setLastName("Ocegueda123");
		});
	}
	
	// test phone number
	@Test
	void testContactClassSetPhone() {
		Contact testContact = new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		testContact.setPhone("2568781234");
		assertTrue(testContact.getPhone().equals("2568781234"));
	}
	
	@Test
	void testContactClassSetPhoneIsNull() {
		Contact testContact = new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			testContact.setPhone(null);
		});
	}
	
	@Test
	void testContactClassSetPhoneIsTooLong() {
		Contact testContact = new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			testContact.setPhone("25655800001");
		});
	}
	
	// test address
	@Test
	void testContactClassSetAddress() {
		Contact testContact = new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		testContact.setAddress("100 Test St, Boaz, AL 35957");
		assertTrue(testContact.getAddress().equals("100 Test St, Boaz, AL 35957"));
	}
	
	@Test
	void testContactClassSetAddressIsNull() {
		Contact testContact = new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			testContact.setAddress(null);
		});
	}
	
	@Test
	void testContactClassSetAddressIsTooLong() {
		Contact testContact = new Contact("1000000001", "Isaac", "Ocegueda",
					"2565580000", "123 Main St, Boaz, AL 35957");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			testContact.setAddress("1234567 Main St, Boaz, AL 35957");
		});
	}
}
