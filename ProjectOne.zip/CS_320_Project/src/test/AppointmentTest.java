/*
 * Author: Isaac Ocegueda
 * Date: 2/9/2024
 * Class: CS 320
 */


package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.util.Date;
import org.junit.jupiter.api.BeforeEach;

import main.Appointment;

class AppointmentTest {

	// initial variables for testing
	private String id, description;
	private String longId, longDescription;
	private Date today, pastDate;
	


	@SuppressWarnings("deprecation")
	@BeforeEach // set up for each test to be more efficient
	void setUp() {
		id = "1000000001";
		description = "Simple test description";
		longId = "10000000001";
		longDescription = "This appointment description is over 50 characters in length";
		today = new Date(2025, 1, 1);
		pastDate = new Date(0);
	}
	// test for creation of appointment class
	@Test
	void testAppointmentClass() {
		Appointment testAppointment = new Appointment(id, today, description);
		assertTrue(testAppointment.getAppointmentId().equals("1000000001"));
		assertTrue(testAppointment.getAppointmentDate().equals(today));
		assertTrue(testAppointment.getAppointmentDescription().equals("Simple test description"));
	}
		
	// test for null id and too long id
	@Test
	void testAppointmentClassId() {
		Appointment testAppointment = new Appointment(id, today, description);
		assertThrows(IllegalArgumentException.class, () ->
			testAppointment.setAppointmentId(null));
		assertThrows(IllegalArgumentException.class, () ->
			testAppointment.setAppointmentId(longId));
		testAppointment.setAppointmentId(id);
		assertEquals(id, testAppointment.getAppointmentId());
	}
		
	
	// test for date null and past date
	@Test
	void testAppointmentClassDate() {
		Appointment testAppointment = new Appointment(id, today, description);
		assertThrows(IllegalArgumentException.class, () ->
			testAppointment.setAppointmentDate(null));
		assertThrows(IllegalArgumentException.class, () ->
			testAppointment.setAppointmentDate(pastDate));
		testAppointment.setAppointmentDate(today);
		assertEquals(today, testAppointment.getAppointmentDate());
	}
		
	// test for appointment description null and too long
	@Test
	void testAppointmentClassDescription() {
		Appointment testAppointment = new Appointment(id, today, description);
		assertThrows(IllegalArgumentException.class, () ->
			testAppointment.setAppointmentDescription(null));
		assertThrows(IllegalArgumentException.class, () ->
			testAppointment.setAppointmentDescription(longDescription));
		testAppointment.setAppointmentDescription(description);
		assertEquals(description, testAppointment.getAppointmentDescription());
	}
}
