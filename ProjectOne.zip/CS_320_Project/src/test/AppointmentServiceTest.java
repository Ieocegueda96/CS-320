/*
 * Author: Isaac Ocegueda
 * Date: 2/9/2024
 * Class: CS 320
 */


package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import main.AppointmentService;

class AppointmentServiceTest {
	// initial variables for testing
	private String id, description;
	private Date today;
		


	@SuppressWarnings("deprecation")
	@BeforeEach // set up for each test to be more efficient
	void setUp() {
		id = "1000000001";
		description = "Simple test description";
		today = new Date(2025, 1, 1);
	}
	
	// test a new appointment
	@Test
	void testAppointmentServiceClassNewAppointment() {
		AppointmentService.addAppointment(id, today, description);
		assertTrue(AppointmentService.appointmentList.get(0).getAppointmentId().equals(id));
		assertTrue(AppointmentService.appointmentList.get(0).getAppointmentDate().equals(today));
		assertTrue(AppointmentService.appointmentList.get(0).getAppointmentDescription().equals(description));
	}
	
	// test delete an appointment
	@Test
	void testAppointmentServiceClassDeleteAppointment() {
		AppointmentService.addAppointment("1234", today, description);
		AppointmentService.deleteAppointment("1234");
		assertTrue(AppointmentService.searchAppointment("1234") == 2);
	}
	
	// test search function
	@Test
	void testAppointmentServiceClassSearchAppointment() {
		AppointmentService.addAppointment("456", today, description);
		assertTrue(AppointmentService.searchAppointment("456") == 1);
	}

}
