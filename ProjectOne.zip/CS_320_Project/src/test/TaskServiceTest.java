/*
 * Author: Isaac Ocegueda
 * Date: 2/1/2024
 * Class: CS 320
 */

package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.TaskService;

class TaskServiceTest {
	
	// test the add task function
	@Test
	void testTaskServiceClassAddTask() {
		TaskService.addTask("1", "Task1", "Testing the task");
		assertTrue(TaskService.taskList.get(0).getTaskId().equals("1"));
		assertTrue(TaskService.taskList.get(0).getTaskName().equals("Task1"));
		assertTrue(TaskService.taskList.get(0).getTaskDescription().equals("Testing the task"));
	}
		
	// test the delete Task function
	@Test
	void testTaskServiceClassDeleteTask() {
		TaskService.addTask("1000000002", "Task2", "Task description");
		TaskService.deleteTask("1000000002");
		assertTrue(TaskService.searchTask("1000000002") == 2);
	}

	// test update of task name
	@Test
	void testTaskServiceClassUpdateTaskName() {
		TaskService.addTask("1000000003", "Task3", "Description");
		TaskService.updateTaskName("1000000003", "3Task");
		assertTrue(TaskService.taskList.get(0).getTaskName().equals("3Task"));
	}
	
	// test update of task description
	@Test
	void testTaskServiceClassUpdateTaskDescription() {
		TaskService.addTask("1000000004", "Test4", "Description");
		TaskService.updateTaskDescription("1000000004", "Other description");
		assertTrue(TaskService.taskList.get(0).getTaskDescription().equals("Other description"));
	}
	
	// test for duplicate ID
	void testTaskServiceDuplicateId() {
		TaskService.addTask("1000000005", "Test5", "Task description");
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			TaskService.addTask("1000000005", "Task6", "Duplicate");
		});
	}
		
}
