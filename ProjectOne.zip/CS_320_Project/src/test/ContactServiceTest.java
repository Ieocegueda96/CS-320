

package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import main.ContactService;

class ContactServiceTest {

	// test the add contact function
	
	
	@Test
	void testContactServiceClassAddContact() {
		ContactService.addContact("9", "Isaac", "Ocegueda", "2565580000", "123 Test St, Boaz, AL 35957");
		assertTrue(ContactService.contactList.get(0).getContactId().equals("9"));
		assertTrue(ContactService.contactList.get(0).getFirstName().equals("Isaac"));
		assertTrue(ContactService.contactList.get(0).getLastName().equals("Ocegueda"));
		assertTrue(ContactService.contactList.get(0).getPhone().equals("2565580000"));
		assertTrue(ContactService.contactList.get(0).getAddress().equals("123 Test St, Boaz, AL 35957"));
	}
	
	// test the delete contact function
	@Test
	void testContactServiceClassDeleteContact() {
		ContactService.addContact("1", "Isaac", "Ocegueda", "2565580000", "123 Test St, Boaz, AL 35957");
		ContactService.deleteContact("1");
		assertTrue(ContactService.searchContact("1") == 2);
	}
	
	// test update of first name
	@Test
	void testContactServiceClassUpdateFirstName() {
		ContactService.addContact("2", "Isaac3", "Ocegueda3", "2565580003", "789 Test St, Boaz, AL 35957");
		ContactService.updateFirstName("2", "Ismael");
		assertTrue(ContactService.contactList.get(0).getFirstName().equals("Ismael"));
	}
	
	// test update of last name
	@Test
	void testContactServiceClassUpdateLastName() {
		ContactService.addContact("3", "Isaac3", "Ocegueda3", "2565580003", "789 Test St, Boaz, AL 35957");
		ContactService.updateLastName("3", "Ortega");
		assertTrue(ContactService.contactList.get(0).getLastName().equals("Ortega"));
	}
	
	// test update of phone number
	@Test
	void testContactServiceClassUpdatePhone() {
		ContactService.addContact("4", "Isaac3", "Ocegueda3", "2565580003", "789 Test St, Boaz, AL 35957");
		ContactService.updatePhone("4", "2565050001");
		assertTrue(ContactService.contactList.get(0).getPhone().equals("2565050001"));
	}
	
	// test update of address
	@Test
	void testContactServiceClassUpdateAddress() {
		ContactService.addContact("5", "Isaac3", "Ocegueda3", "2565580003", "789 Test St, Boaz, AL 35957");
		ContactService.updateAddress("5", "123 E St, Boaz, AL 35957");
		assertTrue(ContactService.contactList.get(0).getAddress().equals("123 E St, Boaz, AL 35957"));
	}
	
	// test for duplicate ID
	@Test
	void testContactServiceDuplicateId() {
		ContactService.addContact("6", "Isaac3", "Ocegueda3", "2565580003", "789 Test St, Boaz, AL 35957");
		Assertions.assertThrows(IllegalArgumentException.class,() -> {
			ContactService.addContact("6", "Isaac4", "Ocegueda4", "2565580004", "123 Test St, Boaz, AL 35957");
		});

	}
	
}
